/* CR#P00393 - GPMS# 5982523- Transaction Approval Clean-Up Patch - Taiwan */
  
  
DELETE FROM PS_CGAP_APPR_DTL WHERE CGAP_TRNSCTN_NAME = 'LCHG';
commit;


DELETE FROM PS_CGAP_APPR_DTL WHERE SETID IN ('TW001','TW002','TW003');
commit;
/







