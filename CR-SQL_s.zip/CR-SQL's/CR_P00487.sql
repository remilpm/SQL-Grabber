/*CR-P00487-GPMS#6311688 - JobCode patch for Tipped Field - Regional */


update sysadm.ps_jobcode_tbl set directly_tipped='N'
where directly_tipped=' '
and upper(substr(jobcode,1,2))  in ( 'SB' ,'GM');
commit;