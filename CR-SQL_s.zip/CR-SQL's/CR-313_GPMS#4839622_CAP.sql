begin
for i in (select a.emplid,a.effseq,a.empl_rcd, a.effdt,a.business_unit
                 from sysadm.ps_job a                 
                                  where effdt =  (select max(effdt) from sysadm.ps_job
		                                  where emplid = a.emplid and effdt <= sysdate)
		 	          and effseq =   (select max(effseq) from sysadm.ps_job 
		                                   where emplid = a.emplid and effdt = a.effdt)
		 	          and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
		                                   where emplid = a.emplid 
		                                   and effdt = a.effdt and effseq = a.effseq))
loop

for j in (select b.emplid,b.effdt,b.cgap_comp_cd from sysadm.ps_cgap_oth_bonus b
		where emplid=i.emplid
		and cgap_cap_eligib<>'Y')		
loop


update sysadm.ps_cgap_oth_bonus  set cgap_cap_eligib = 'N'
where emplid = j.emplid
and effdt = j.effdt
and cgap_comp_cd = j.cgap_comp_cd;
end loop;
end loop;
commit;
end;
/ 