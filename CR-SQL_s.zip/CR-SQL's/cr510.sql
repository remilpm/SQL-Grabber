update ps_names a set a.name = initcap(a.name)
where exists (select 1 from ps_job b 
              where emplid = a.emplid
and effdt = (select max(effdt) from ps_job 
              where emplid = b.emplid
              and effdt <= sysdate
              and empl_rcd = b.empl_rcd)
and effseq = (select max(effseq) from ps_job
              where emplid = b.emplid 
              and effdt = b.effdt 
              and empl_rcd = b.empl_rcd)
and business_unit = 'JPNNS')
and name_type = 'PRI'
and upper(name) = name;