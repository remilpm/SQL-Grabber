/* Names Patch for Taiwan and Thailand CR-536 - GPMS#6537782 */ 

declare
prf_emplid	varchar2(11);
prf_effdt       date;
prf_fname	varchar2(30);
prf_lname	varchar2(30);
pri_emplid	varchar2(11);
pri_effdt       date;
pri_fname	varchar2(30);
pri_lname	varchar2(30);
ac_name		varchar2(60);
no_actn		number(1) := 0;

begin
 for i in (select a.emplid,a.effdt,a.first_name,a.last_name, b.business_unit
    from sysadm.ps_names a, sysadm.ps_job b 
    where a.emplid=b.emplid
    and b.effdt = (select max(effdt) from ps_job where emplid = b.emplid and effdt <= sysdate and empl_rcd = b.empl_rcd)
    and b.effseq = (select max(effseq) from ps_job where emplid = b.emplid and effdt = b.effdt and empl_rcd = b.empl_rcd)
    and a.name_type='PRF'
    and (ascii(substr(a.first_name,1,1)) not between 65 and 90 and ascii(substr(a.first_name,1,1)) not between 97 and 122)
    and (ascii(substr(a.last_name,1,1)) not between 65 and 90 and ascii(substr(a.last_name,1,1)) not between 97 and 122)
    and b.business_unit in ('TWNCB','THACB')) 	 
 		 		 	          
                              
loop

dbms_output.put_line(i.effdt||'-'||i.emplid);
/* Select for Name_Type - PREFERRED */
no_actn := 0;
begin
select cc.emplid,cc.effdt,cc.first_name,cc.last_name 
into prf_emplid, prf_effdt, prf_fname, prf_lname
from ps_names cc
where cc.emplid=i.emplid
and cc.effdt=(select max(dd.effdt) from sysadm.ps_names dd
               	where dd.emplid = i.emplid 
               	and   dd.effdt<= i.effdt
               	and dd.name_type = cc.name_type)
and cc.name_type='PRF';
exception
when no_data_found then
no_actn := 1;
end;

if no_actn = 0 then            			

/* Select for Name_Type - PRIMARY */   
begin
select ee.emplid,ee.effdt,ee.first_name,ee.last_name 
into pri_emplid, pri_effdt, pri_fname, pri_lname
from ps_names ee
where ee.emplid=i.emplid
and ee.effdt=(select max(ff.effdt) from sysadm.ps_names ff
              	where ff.emplid = i.emplid 
               	and   ff.effdt<= i.effdt
               	and ff.name_type = ee.name_type)
and   ee.name_type='PRI';
exception
when no_data_found then
no_actn := 1;
end;

if no_actn = 0 then
  if i.business_unit = 'TWNCB' then
  ac_name := prf_fname||' '||prf_lname;
  end if;
  
  if i.business_unit = 'THACB' then
  ac_name := prf_lname||' '||prf_fname;
  end if;             			
               			
  If prf_effdt <> pri_effdt Then
  
  INSERT INTO PS_NAMES
  SELECT
  EMPLID,                 
  'PRI',              
  prf_effdt,                  
  COUNTRY_NM_FORMAT,      
  NAME,                   
  NAME_INITIALS,          
  NAME_PREFIX,            
  NAME_SUFFIX,            
  NAME_ROYAL_PREFIX,      
  NAME_ROYAL_SUFFIX,      
  NAME_TITLE,             
  LAST_NAME_SRCH,         
  FIRST_NAME_SRCH,        
  LAST_NAME,              
  FIRST_NAME,             
  MIDDLE_NAME,            
  SECOND_LAST_NAME,       
  SECOND_LAST_SRCH,       
  ac_name,            
  PREF_FIRST_NAME,        
  PARTNER_LAST_NAME,      
  PARTNER_ROY_PREFIX,     
  LAST_NAME_PREF_NLD   from PS_NAMES
  WHERE EMPLID=i.EMPLID
  AND EFFDT=pri_effdt
  AND NAME_TYPE='PRI';
  
  /**** AUDIT ****/
  
  INSERT INTO PS_CGAP_AUDIT_PER1
            SELECT
           'NM31971',
            SYSDATE,
            'A',
            'NAMES',
           EMPLID,
   ' ' ,
   NAME,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
    '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
  ' ',
   ' ' ,
   0,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   NAME_TYPE,
   COUNTRY_NM_FORMAT,
   NAME_INITIALS,
   NAME_PREFIX,
   NAME_SUFFIX,
   NAME_ROYAL_PREFIX,
   NAME_ROYAL_SUFFIX,
   NAME_TITLE,
   LAST_NAME_SRCH,
   FIRST_NAME_SRCH,
   LAST_NAME,
   FIRST_NAME,
   MIDDLE_NAME,
   SECOND_LAST_NAME,
   SECOND_LAST_SRCH,
   NAME_AC,
   PREF_FIRST_NAME,
   PARTNER_LAST_NAME,
   PARTNER_ROY_PREFIX,
   LAST_NAME_PREF_NLD
           FROM PS_NAMES
           where emplid = i.emplid
         and name_type='PRI' and effdt = prf_effdt;
  
  dbms_output.put_line('Preferred-Effdt :  '||prf_effdt);
  dbms_output.put_line('Preferred-Emplid : '||prf_emplid); 
  
  	/*Insert Logic -DML - 01*/
  Else
  
  dbms_output.put_line('Primary-Effdt :  '||pri_effdt); 
  dbms_output.put_line('Primary-Emplid : '||pri_emplid);
  
  	/*Update Logic - DML - 02*/
  	/* *** AUDIT *** */
  	
  	INSERT INTO PS_CGAP_AUDIT_PER1
	          SELECT
	         'NM31971',
	          SYSDATE,
	          'C',
	          'NAMES',
	         EMPLID,
	 ' ' ,
	 NAME,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	  '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	' ',
	 ' ' ,
	 0,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 ' ' ,
	 '' ,
	 NAME_TYPE,
	 COUNTRY_NM_FORMAT,
	 NAME_INITIALS,
	 NAME_PREFIX,
	 NAME_SUFFIX,
	 NAME_ROYAL_PREFIX,
	 NAME_ROYAL_SUFFIX,
	 NAME_TITLE,
	 LAST_NAME_SRCH,
	 FIRST_NAME_SRCH,
	 LAST_NAME,
	 FIRST_NAME,
	 MIDDLE_NAME,
	 SECOND_LAST_NAME,
	 SECOND_LAST_SRCH,
	 NAME_AC,
	 PREF_FIRST_NAME,
	 PARTNER_LAST_NAME,
	 PARTNER_ROY_PREFIX,
	 LAST_NAME_PREF_NLD
	         FROM PS_NAMES
	         where emplid = i.emplid
         and name_type='PRI' and effdt = i.effdt;
         
         update sysadm.ps_names set name_ac = ac_name
	 where emplid = i.emplid and name_type = 'PRI'  
	 and effdt = i.effdt;
       
  End If;
  
  
  /*Delete Logic DML - 03*/
  /* *** AUDIT *** */
  
  INSERT INTO PS_CGAP_AUDIT_PER1
            SELECT
           'NM31971',
            SYSDATE,
            'D',
            'NAMES',
           EMPLID,
   ' ' ,
   NAME,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
    '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
  ' ',
   ' ' ,
   0,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   NAME_TYPE,
   COUNTRY_NM_FORMAT,
   NAME_INITIALS,
   NAME_PREFIX,
   NAME_SUFFIX,
   NAME_ROYAL_PREFIX,
   NAME_ROYAL_SUFFIX,
   NAME_TITLE,
   LAST_NAME_SRCH,
   FIRST_NAME_SRCH,
   LAST_NAME,
   FIRST_NAME,
   MIDDLE_NAME,
   SECOND_LAST_NAME,
   SECOND_LAST_SRCH,
   NAME_AC,
   PREF_FIRST_NAME,
   PARTNER_LAST_NAME,
   PARTNER_ROY_PREFIX,
   LAST_NAME_PREF_NLD
           FROM PS_NAMES
           where emplid=i.emplid and effdt=i.effdt and name_type='PRF';
         
         
  
  Delete from ps_names where emplid=i.emplid and effdt=i.effdt and name_type='PRF';
 
 else
 dbms_output.put_line('No Primary name records for ID : '||i.emplid);
 end if;
 else
 dbms_output.put_line('No Preferred name records for ID : '||i.emplid);
 end if;
 				     
end loop;
commit;
end;
/

               
 