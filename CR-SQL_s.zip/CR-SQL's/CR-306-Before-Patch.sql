
Spool C:\CITIWORK\SpoolFiles\CR306\Patch01.txt
select emplid,effdt,effseq,empl_rcd,empl_class,paygroup from ps_job
where empl_class='SEA';
spool off
/



Spool C:\CITIWORK\SpoolFiles\CR306\Patch02.txt
select emplid,effdt,effseq,empl_rcd,empl_class,paygroup from ps_job
where empl_class='SEA';
spool off
/



Spool C:\CITIWORK\SpoolFiles\CR306\Patch03.txt
select emplid,effdt,effseq,empl_rcd,empl_class,paygroup from ps_job
where empl_class='SEA';
spool off
/



Spool C:\CITIWORK\SpoolFiles\CR306\Patch04.txt
select emplid,effdt,effseq,empl_rcd,empl_class,paygroup from ps_job
where empl_class='SEA';
spool off
/



Spool C:\CITIWORK\SpoolFiles\CR306\Patch05.txt
select emplid,effdt,effseq,empl_rcd,empl_class,paygroup from ps_job
where empl_class='SEA';
spool off
/



Spool C:\CITIWORK\SpoolFiles\CR306\Patch06.txt
select emplid,effdt,effseq,empl_rcd,empl_class,paygroup from ps_job
where empl_class='SEA';
spool off
/

