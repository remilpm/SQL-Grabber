

/* CR#P00366 - Address Type Purge for SGP*/

begin
for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,a.business_unit 
                 from sysadm.ps_job a
		 where a.business_unit='SGPCB'
		 and effdt =  (select max(effdt) from sysadm.ps_job
		                                  where emplid = a.emplid and effdt <= sysdate)
		 	          and effseq =   (select max(effseq) from sysadm.ps_job 
		                                   where emplid = a.emplid and effdt = a.effdt)
		 	          and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
		                                   where emplid = a.emplid 
		                                   and effdt = a.effdt and effseq = a.effseq))
loop


delete sysadm.ps_addresses   
where emplid = i.emplid
and   country=' '
and  address_type in ('HOME','MAIL','OTH');
end loop;
commit;
end;
/