UPDATE PS_JOBCODE_TBL SET DESCR = 'Sales Distribution Support Ma' where jobcode='AP0295' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Marketing Communications Offi' where jobcode='AP0951' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Regional Insurance Direct Mar' where jobcode='AP0987' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'MD  Regional Global Mkts O&T ' where jobcode='AP1304' and effdt ='15-SEP-2004';
&T
UPDATE PS_JOBCODE_TBL SET DESCR = 'Unit Head - Control and Inves' where jobcode='AP1349' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Unit Head - Reg.Derivatives '  where jobcode= 'AP1350' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Derivatives Settlement Superv' where jobcode= 'AP1616' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Fixed Income Operations Offic' where jobcode='AP1618' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Unit Head - Reg Derivatives O' where jobcode='AP1638' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Head of Portfolio Mgmt- Cards' where jobcode='AP1697' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Jr Citigold Acquisition Offic' where jobcode='AP1903' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Sales Productivity and MIS An' where jobcode='AP2099' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Direct Sales Dev Channel Team' where jobcode='AP2392' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Relationship Manager - Acquis' where jobcode='AP2403' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Branch Treasury Services Tele' where jobcode='AP2601' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'VP - Treasury System Manageme' where jobcode='AP2935' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Bus Analyst-Head of User Supp' where jobcode='AP2938' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Vice President - Investor Sal' where jobcode='AP3194' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Financial Risk Control Assist' where jobcode='AP3224' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Business Planning & Analysis ' where jobcode='AP3282' and effdt ='15-SEP-2004';
& Analysis
UPDATE PS_JOBCODE_TBL SET DESCR = 'Compensation & Benefit Specia' where jobcode='AP3294' and effdt ='15-SEP-2004';
& Benefit
UPDATE PS_JOBCODE_TBL SET DESCR = 'AVP- Acquisition Marketing'    where jobcode='AP3311' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Collector' where jobcode='AP3312' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Ops Mgmt-Processng-Wrkflw Crd' where jobcode='AP3313' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'SALES' where jobcode='AP3314' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'O&T  Director' where jobcode='AP3359' and effdt ='15-SEP-2004';
&T
UPDATE PS_JOBCODE_TBL SET DESCR = 'HD OF PORTFOLIO MGMT-CARDS MK' where jobcode='AP3368' and effdt ='15-SEP-2004';
UPDATE PS_JOBCODE_TBL SET DESCR = 'Citigold Business Development' where jobcode='AP3398' and effdt ='15-SEP-2004';
COMMIT;
