begin
     for i in (select * from sysadm.ps_job a
               where a.emplid in
               ('1000016297',
                '1000016298',
                '1000016300',
                '1000016302',
                '1000016303',
                '1000161579',
                '1000521436',
                '1000087901',
                '1000087902',
                '1000087903')
               and effdt =    (select max(effdt) from sysadm.ps_job
               			where emplid = a.emplid 
               			and empl_rcd = a.empl_rcd and effdt <= sysdate)
               and effseq =   (select max(effseq) from sysadm.ps_job
                                where emplid = a.emplid and effdt = a.effdt
                                and empl_rcd = a.empl_rcd))               
loop      	
   update sysadm.ps_job set annual_rt=0,monthly_rt=0,daily_rt=0,hourly_rt=0
   where emplid = i.emplid
     and effdt  = i.effdt
     and effseq = i.effseq
     and empl_rcd=i.empl_rcd;      
end loop;
commit;
end;
/