
select distinct recname from psrecfield a
where fieldname = 'OPRID' and recname not like 'PS%'
and exists (select 1 from psrecdefn where recname = a.recname and rectype = 0)
and not exists (select 1 from all_tables where substr(table_name,4) = a.recname);
