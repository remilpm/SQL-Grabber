/* CR-P00536 - SQL#01 */
select a.emplid,a.effdt,a.first_name,a.last_name, b.business_unit
    from sysadm.ps_names a, sysadm.ps_job b 
    where a.emplid=b.emplid
    and a.name_type='PRF'
    and (ascii(substr(a.first_name,1,1)) not between 65 and 90 and ascii(substr(a.first_name,1,1)) not between 97 and 122)
    and (ascii(substr(a.last_name,1,1)) not between 65 and 90 and ascii(substr(a.last_name,1,1)) not between 97 and 122)
    and b.business_unit in ('TWNCB','THACB')
    and b.effdt =  (select max(effdt) from sysadm.ps_job
 		                                  where emplid = b.emplid and 
 		                                    empl_rcd=b.empl_rcd and
 		                                    effdt<=sysdate)
 		 	          and b.effseq =   (select max(effseq) from sysadm.ps_job 
 		                                   where emplid = b.emplid and
 		                                   empl_rcd=b.empl_rcd and 
 		                                   effdt = b.effdt);

/* CR-P00536 - SQL#02 */

select a.emplid,a.name_type,a.effdt,a.last_name,a.first_name
from ps_names a
where a.name_type = 'PRF'
and exists (select 1 from ps_names b where a.emplid = b.emplid
and b.name_type = 'PRI' and b.effdt <> a.effdt)
and (ascii(substr(a.first_name,1,1)) not between 65 and 90 and ascii(substr(a.first_name,1,1)) not between 97 and 122)
and (ascii(substr(a.last_name,1,1)) not between 65 and 90 and ascii(substr(a.last_name,1,1)) not between 97 and 122)
and exists (select 1 from ps_job j where emplid = a.emplid
and effdt = (select max(effdt) from ps_job where emplid = j.emplid and effdt <= sysdate and empl_rcd = j.empl_rcd)
and effseq = (select max(effseq) from ps_job where emplid = j.emplid and effdt = j.effdt and empl_rcd = j.empl_rcd)
and business_unit in ('TWNCB','THACB'));
