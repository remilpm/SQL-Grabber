/*********************************************************/
/*CR#P00404 - GPMS#5992871 - Data Patch- Job Jr Table    */
/*********************************************************/

DELETE SYSADM.PS_JOB_JR
WHERE EMPLID='0004545753'
AND EFFDT='16-APR-2001'
AND EFFSEQ=1
AND EMPL_RCD=0;
commit;
/
