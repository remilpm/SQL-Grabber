/*********************************************************/
/*CR#P00510 - GPMS#6458666 - Names Patch- Japan          */
/*********************************************************/

begin
for i in (select *  from sysadm.ps_job a
                 where a.business_unit='JPNNS'
		 and a.effdt =  (select max(effdt) from sysadm.ps_job
		                 where emplid = a.emplid
		                 and effdt <= sysdate
		                 and empl_rcd = a.empl_rcd)
		 and a.effseq = (select max(effseq) from sysadm.ps_job
		                 where emplid = a.emplid
		                 and effdt = a.effdt
		                 and empl_rcd = a.empl_rcd))
loop

	

update sysadm.ps_names 
set name=initcap(name)
,first_name=initcap(first_name),last_name=initcap(last_name)
where emplid = i.emplid
and   name_type='PRI';

update sysadm.ps_personal_data
set name=initcap(name),first_name=initcap(first_name),last_name=initcap(last_name)
where emplid = i.emplid;


INSERT INTO PS_CGAP_AUDIT_PER1
            SELECT
           'KC25739',
            SYSDATE,
            'C',
            'NAMES',
           EMPLID,
   ' ' ,
   NAME,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
    '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
  ' ',
   ' ' ,
   0,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   ' ' ,
   ' ' ,
   ' ' ,
   ' ' ,
   '' ,
   NAME_TYPE,
   COUNTRY_NM_FORMAT,
   NAME_INITIALS,
   NAME_PREFIX,
   NAME_SUFFIX,
   NAME_ROYAL_PREFIX,
   NAME_ROYAL_SUFFIX,
   NAME_TITLE,
   LAST_NAME_SRCH,
   FIRST_NAME_SRCH,
   LAST_NAME,
   FIRST_NAME,
   MIDDLE_NAME,
   SECOND_LAST_NAME,
   SECOND_LAST_SRCH,
   NAME_AC,
   PREF_FIRST_NAME,
   PARTNER_LAST_NAME,
   PARTNER_ROY_PREFIX,
   LAST_NAME_PREF_NLD
           FROM PS_NAMES
           where emplid = i.emplid
         and name_type='PRI'; 
end loop;
commit;
end;
/