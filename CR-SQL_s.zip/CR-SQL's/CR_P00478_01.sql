/*  CR-P00478 Job Junior Patch  */

Set Serveroutput on size 10000;

begin
for i in (select * from sysadm.ps_job a
where a.emplid in
('0000496141',      
 '0000590809',  
 '0000912546',      
 '0001001945',      
 '0001525892',      
 '0002484984',      
 '0002492935',     
 '0002495581',      
 '0004792161'                   
 ))
		
loop
begin


INSERT INTO PS_JOB_JR
SELECT 
i.EMPLID,                         
i.effseq,                       
i.effdt,                          
i.empl_rcd,                        
SYSDATE,                   
 LASTUPDOPRID,                   
 TAXCODE_UK,                     
 TAX_BASIS_UK,                   
 WORKER_TYPE_MEX,                
 REDUCED_WEEK_MEX,               
 LOCATED_CD_MEX,               
 SALARY_TYPE_MEX,               
 IMS_TERM_DT_MEX,               
 CASUAL_IND,               
 SALARY_PACKAGED,               
 PAYROLL_STATE_AUS,
 CLASSN_CURRENT_AUS,             
 WORK_SECTOR_AUS,                
 FUNCTION_AUS,                   
 ANN_CNTACT_HRS_AUS,             
 TEACH_WEEKS_AUS,                
 CASUAL_TYPE_AUS,                
 TERM_TYPE_AUS,                  
 TERM_LTD_AUS,                   
 BALANCE_GRP_NUM,                
 FP_ACTION_2,                    
 CTG_RATE,                       
 FP_LEGALSTAT_CD,                
 FP_SCNDMT_CD,                   
 FP_SCND_TYP,                    
 FP_CIVIL_PENSION,               
 FP_SOURCE_ORG,                  
 FP_RECEP_ORG,                   
 FP_RETURN_CD,                   
 FP_PR_LEGSTA,                   
 FP_FOREND_DT,                   
 FP_END_DT,                      
 FP_CAREFRZPCT,                  
 FP_HIR_DOS_SIT,                 
 FP_PT_PCT_DET,                  
 FP_TITLE_NUM,                   
 FP_DURATION_PCT,                
 FP_RATING_PRS_FLG,              
 FP_BUDGET_NBR,                  
 FP_HDCNT_NBR,                   
 FP_POTENT_NBR,                  
 FP_RANK_CD,                     
 FP_STEP_CD,                     
 FP_RK_ENT_DT,                   
 FP_CORPS_CD,                    
 FP_CHG_COR_DT,                  
 FP_CATG_FP,                     
 FP_CATG_LEVEL,                  
 FP_RK_TRIALPD,                  
 FP_STEP_END_DT,                 
 FP_FOR_PROM_DT,                 
 FP_NOMINATION_DT,               
 FP_TRAINEE,                     
 FP_TRNE_POSN,                   
 FP_RK_PD_END_DT,                
 FP_SANCTION,                    
 FP_DOWN_GRA,                    
 FP_APPL_SAL_DT,                 
 FP_CHG_IND,                     
 FP_CLD_INST,                    
 FP_SETID_RANK,                  
 FP_INSTALL_DT,                  
 FP_EQUIV_STEP,                  
 FP_STEP_CD2,                    
 FP_BUSINESS_CD,                 
 FP_APPL_DT,                     
 FP_CHG_SAL,                     
 FP_POINTYP_CD,                  
 FP_GROSS_IND,                   
 FP_INCS_IND,                    
 FP_INCS_IND2,                  
 FP_PT_PCT,                      
 FP_PT_END_DT,                   
 FP_PT_FOREND_DT,                
 FP_COMPRATE,                   
 FP_INST_STAT,                   
 FP_RETROSPECT,                  
 FP_ROW_END_DT,                  
 LAST_UPDATE_DATE,               
 OTHER_ID_JPN,                   
 INTCP_XFR_FLG,                 
 INTCP_XFR_START_DT,             
 INTCP_XFR_END_DT,               
 INTCP_BUS_UNIT,                 
 INTCP_DEPTID,                   
 INTCP_DEPTID2,                  
 INTCP_SETID_DEPT,              
 INTCP_COMPANY,                  
 INTCP_COMPANY2,                 
 INTCP_SUPV_LVL_ID,              
 INTCP_SUPV_LVL_ID2,             
 SUPV_LVL_ID,                   
 EXPECTED_END_DATE,             
 AUTO_END_FLG,                   
 DUTIES_TYPE,                    
 ASSIGNMENT_ID,                  
 TARGET_COMPRATE,                
 CMP_DONT_ABSORB,                
 SSN_EMPLOYER,                   
 UNITA_PROD_CD,                  
 ACTION_ITA,                    
 ACTION_REASON_ITA,              
 SPECIAL_HIRCTG_ITA,             
 PART_TIME_TYPE_ITA,             
 PART_TIME_PERC_ITA,             
 PARTTIME_ENDDT_ITA,             
 CGAP_REMN_TYPE   FROM PS_JOB_JR WHERE
	emplid   = i.emplid 
	and rownum < 2;
	

exception

when others then
dbms_output.put_line('Data Found:' ||i.EMPLID);

end;
end loop;
commit;
end;
/


