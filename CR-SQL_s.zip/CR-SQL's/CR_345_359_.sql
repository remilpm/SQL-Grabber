/**************** BELOW PATCH IS FOR  CR#345 - Japan *******************/

/* CR#P00345 - Action_Reason- Patch 01 */

begin
for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,
                 a.action,a.action_reason,a.business_unit 
                 from sysadm.ps_job a
		 where a.business_unit='JPNCF'
		 and effdt =  (select max(effdt) from sysadm.ps_job
		                                  where emplid = a.emplid and effdt <= sysdate)
		 	          and effseq =   (select max(effseq) from sysadm.ps_job 
		                                   where emplid = a.emplid and effdt = a.effdt)
		 	          and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
		                                   where emplid = a.emplid 
		                                   and effdt = a.effdt and effseq = a.effseq))
loop


update sysadm.ps_job set action_reason='CON'
where emplid = i.emplid
and   action='ADD'
and action_reason = ' ';
end loop;
commit;
end;
/

/* CR#P00345 - Action_Reason- Patch 02 */

begin
for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,
                 a.action,a.action_reason,a.business_unit 
                 from sysadm.ps_job a
		 where a.business_unit='JPNCF'
		 and effdt =  (select max(effdt) from sysadm.ps_job
		                                  where emplid = a.emplid and effdt <= sysdate)
		 	          and effseq =   (select max(effseq) from sysadm.ps_job 
		                                   where emplid = a.emplid and effdt = a.effdt)
		 	          and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
		                                   where emplid = a.emplid 
		                                   and effdt = a.effdt and effseq = a.effseq))
loop


update sysadm.ps_job set action_reason='CHL'
where emplid = i.emplid
and   action='FSC'
and action_reason = ' ';
end loop;
commit;
end;
/

/* CR#P00345 - Employee Class- Patch 04-Agency/Temp */

begin
for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,
                 a.action,a.empl_status,a.empl_class
                 from sysadm.ps_job a
		 where a.business_unit='JPNCF'
		 and effdt =  (select max(effdt) from sysadm.ps_job
		                                  where emplid = a.emplid and effdt <= sysdate)
		 	          and effseq =   (select max(effseq) from sysadm.ps_job 
		                                   where emplid = a.emplid and effdt = a.effdt)
		 	          and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
		                                   where emplid = a.emplid 
		                                   and effdt = a.effdt and effseq = a.effseq))
loop


update sysadm.ps_job set empl_class ='G'
where emplid = i.emplid
and   jobcode ='00903'
and (empl_status = 'A' or  empl_status = 'L');
end loop;
commit;
end;
/

/* CR#P00345 - Employee Class- Patch 05 - Contractor */

begin
for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,
                 a.action,a.empl_status,a.empl_class
                 from sysadm.ps_job a
		 where a.business_unit='JPNCF'
		 and effdt =  (select max(effdt) from sysadm.ps_job
		                                  where emplid = a.emplid and effdt <= sysdate)
		 	          and effseq =   (select max(effseq) from sysadm.ps_job 
		                                   where emplid = a.emplid and effdt = a.effdt)
		 	          and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
		                                   where emplid = a.emplid 
		                                   and effdt = a.effdt and effseq = a.effseq))
loop


update sysadm.ps_job set empl_class ='R'
where emplid = i.emplid
and   jobcode in ('00900','00901','00902')
and (empl_status = 'A' or  empl_status = 'L');
end loop;
commit;
end;
/

/* CR#P00345 - Last Name- Patch 06 - Names */

begin
for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,
                 a.action,a.empl_status,a.empl_class
                 from sysadm.ps_job a
		 where a.business_unit='JPNCF'
		 and  (empl_status = 'R' or empl_status='T')
		 and effdt =  (select max(effdt) from sysadm.ps_job
		                                  where emplid = a.emplid and effdt <= sysdate)
		 	          and effseq =   (select max(effseq) from sysadm.ps_job 
		                                   where emplid = a.emplid and effdt = a.effdt)
		 	          and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
		                                   where emplid = a.emplid 
		                                   and effdt = a.effdt and effseq = a.effseq))
loop


update sysadm.ps_names set last_name ='Included in First Name', last_name_srch = 'Included in First Name'
where emplid = i.emplid
and   name_type='PRI'
and  last_name = ' ';
end loop;
commit;
end;
/

/* CR#P00345 - Standard Hours - Patch 07,08,09 - Std_Hours */

begin
for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,
                 a.action,a.empl_status,a.empl_class,a.business_unit
                 from sysadm.ps_job a
		 where a.business_unit in ('JPNCF','JPNCB','JPNAM')		 
		 and effdt =  (select max(effdt) from sysadm.ps_job
		                                  where emplid = a.emplid and effdt <= sysdate)
		 	          and effseq =   (select max(effseq) from sysadm.ps_job 
		                                   where emplid = a.emplid and effdt = a.effdt)
		 	          and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
		                                   where emplid = a.emplid 
		                                   and effdt = a.effdt and effseq = a.effseq))
loop

If i.business_unit='JPNCF' then
update sysadm.ps_job set std_hours ='38.75'
where emplid=i.emplid
and std_hours = '0';
End If;

If i.business_unit='JPNCB' then
update sysadm.ps_job set std_hours ='36.25'
where emplid=i.emplid
and std_hours = '0';
End If;

If i.business_unit='JPNAM' then
update sysadm.ps_job set std_hours ='37.50'
where emplid=i.emplid
and std_hours = '0';
End If;
end loop;
commit;
end;
/


/**************** BELOW PATCH IS FOR  CR#359 Regional Patch *******************/

/*  CR-P00359 Location Field Patch-01 - CNV */


update ps_job a set location = 'CNV', setid_location = setid_dept
where location = ' '
and not exists (select 1 from ps_job b
		where emplid = a.emplid
		and effdt = a.effdt
		and effseq = a.effseq
		and empl_rcd = a.empl_rcd
		and effdt =    (select max(Effdt) from ps_job
				where emplid = b.emplid
				and effdt <= sysdate)
		and effseq =   (select max(effseq) from ps_job
				where emplid = b.emplid 
				and effdt = b.effdt)
		and empl_rcd = (select max(empl_rcd) from ps_job
				where emplid = b.emplid
				and effdt = b.effdt
				and effseq = b.effseq));

commit;
/
/*  CR-P00359 Action- Action Reason Patch-02 - CNV */

begin
for i in (select * from sysadm.ps_job a	)	
		
loop

If i.action='ADD' and i.action_reason=' ' then
	update ps_job set action_reason='CNV' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='ADL' and i.action_reason=' ' then
	update ps_job set action_reason='CNV' 
	where emplid=i.emplid 
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='ASC' and i.action_reason=' ' then
	update ps_job set action_reason='ASC' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='ASG' and i.action_reason=' ' then
	update ps_job set action_reason='ASG' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='DEM' and i.action_reason=' ' then
	update ps_job set action_reason='DEM' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='DTA' and i.action_reason=' ' then
	update ps_job set action_reason='DTA' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='HIR' and i.action_reason=' ' then
	update ps_job set action_reason='HIR' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='JRC' and i.action_reason=' ' then
	update ps_job set action_reason='JRC' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='LOA' and i.action_reason=' ' then
	update ps_job set action_reason='LOA' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='PRO' and i.action_reason=' ' then
	update ps_job set action_reason='PRO' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='REH' and i.action_reason=' ' then
	update ps_job set action_reason='REH' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq 
	and empl_rcd=i.empl_rcd;
End If;

If i.action='RFL' and i.action_reason=' ' then
	update ps_job set action_reason='RFL' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='TER' and i.action_reason=' ' then
	update ps_job set action_reason='OTH' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

If i.action='XFR' and i.action_reason=' ' then
	update ps_job set action_reason='XFR' 
	where emplid=i.emplid
	and effdt=i.effdt
	and effseq=i.effseq
	and empl_rcd=i.empl_rcd;
End If;

end loop;
commit;
end;
/

/*  CR-P00359  Std-Hours -All Rows Including History - Patch-03   */

update sysadm.ps_job set std_hours=40 where std_hours=0;
commit;
/



/*  CR-P00359  Empl_Class -All Rows Including History - Patch-04   */

update sysadm.ps_job set empl_class ='D' where empl_class =' ';
commit;
/


/*  CR-P00359  Pay Group -All Rows Including History - Patch-05   */

update sysadm.ps_job set paygroup ='XXX' where paygroup =' ';
commit;
/
