update ps_names set name_type='GIV' where emplid='1000115029' and name_type='PRI';
commit;
