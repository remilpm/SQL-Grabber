 /************************************************************************/
 /* CR-P00380 and CR-P00389 SQL Patches                                  */
 /************************************************************************/
 
 
 
 /* CR#P00380 - Sal Admin Patch  for AUCGP - Patch# 1 */
  
update sysadm.ps_job a set sal_admin_plan='XXXX' , grade='XXX'          
where a.business_unit='AUCGP'
and exists (select 1 from ps_dept_tbl d
        where setid=a.setid_dept and deptid=a.deptid
                             and d.cgap_biz_group_cd in('100','200','300','700')
                             and d.effdt= (select max(dd.effdt) from ps_dept_tbl dd
                                          where d.setid=dd.setid
                                          and d.deptid=dd.deptid
                                          and dd.effdt <= a.effdt));

commit; 
/


/* CR#P00380 - Sal Admin Patch  for CGMAS - Patch# 2 */ 
 
update  sysadm.ps_job set sal_admin_plan='XXXX',grade='XXX'  
where business_unit='CGMAS';   
commit;
/
 
/* CR#P00380 - Sal Admin Patch  for JPNAM - Patch# 3 */

update  sysadm.ps_job set sal_admin_plan='SSB',grade='XXX'  
where business_unit='JPNAM';
commit;
/

/* CR#P00380 - Sal Admin Patch  for JPNNS - Patch# 4 */

update  sysadm.ps_job set sal_admin_plan='JPNS',grade='XXX'  
where business_unit='JPNNS';
commit;
/
