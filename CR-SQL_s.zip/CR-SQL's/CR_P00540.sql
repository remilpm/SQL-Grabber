/* GPMS# 6544108 - CR-P00540 - Employee Status Patch for 'INDCB'*/
 


begin
     for i in (select * from sysadm.ps_job a
               where a.business_unit = 'INDCB'
               and a.action ='TER' 
               and a.action_reason = 'TAF' 
               and a.empl_status = 'A'
               and effdt =    (select max(effdt) from sysadm.ps_job
               			where emplid = a.emplid 
               			and empl_rcd = a.empl_rcd and effdt <= sysdate)
               and effseq =   (select max(effseq) from sysadm.ps_job
                                where emplid = a.emplid and effdt = a.effdt
                                and empl_rcd = a.empl_rcd))
               
               
loop

   
   update sysadm.ps_job  set empl_status='T'
   where emplid = i.emplid;    	

end loop;
commit;
end;
/