/*********************************************************/
/*CR#P00527 - GPMS#6477436 - Data Patch- Job Jr Table    */
/*********************************************************/

DELETE SYSADM.PS_JOB_JR
WHERE EMPLID='0003319904'
AND EFFDT='21-FEB-2000'
AND EFFSEQ=2
AND EMPL_RCD=0;

DELETE SYSADM.PS_JOB_JR
WHERE EMPLID='0003319904'
AND EFFDT='01-JUL-2001'
AND EFFSEQ=2
AND EMPL_RCD=0;
/
commit;
