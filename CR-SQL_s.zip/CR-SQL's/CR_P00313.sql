update sysadm.ps_cgap_oth_bonus  set cgap_cap_eligib = 'N' where cgap_cap_eligib<>'Y';
commit;

/ 