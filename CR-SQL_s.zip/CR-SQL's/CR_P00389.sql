/***************************************************/
/*CR#P00389 - Sal Admin Patch  for JPNCF- Patch# 1 */
/***************************************************/

update  sysadm.ps_job set sal_admin_plan='CFJ',grade='XXX'  
where business_unit='JPNCF'
and sal_admin_plan=' '
and grade=' ';
commit;

/


/***************************************************/
/*CR#P00389 - Sal Admin Patch  for JPNCF- Patch# 2 */
/***************************************************/

update  sysadm.ps_job set grade='XXX' 
where business_unit='JPNCF'
and grade =' ';
commit;



/

/***************************************************/
/*CR#P00389 - Sal Admin Patch  for JPNCF- Patch# 3 */
/***************************************************/

update  sysadm.ps_job set sal_admin_plan='CFJ' 
where business_unit='JPNCF'
and sal_admin_plan=' ';
commit;
/