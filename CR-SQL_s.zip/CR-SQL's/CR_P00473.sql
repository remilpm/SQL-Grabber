/* CR-P00473 - Data Clean Up patch for Job Junior Record */

delete sysadm.ps_job where emplid='0000967808' and effseq=1 and empl_rcd=0 and effdt='01-NOV-99';
commit;


begin
     for i in (select emplid,effdt,effseq,empl_rcd
               from sysadm.ps_job 
               where emplid in 
               ('1000008103',
		'1000008177',
		'0000967808',
		'0003318092',
		'0000569966',
		'1000030272',
		'1000040362',
		'1000073805',
		'1000073731',
		'1000116871',
		'1000087720',
		'1000131993',
		'1000181382'))               
loop

      
   update sysadm.ps_job_jr set effdt=i.effdt, effseq=i.effseq,empl_rcd=i.empl_rcd
   where emplid = i.emplid;	
   
end loop;
commit;
end;
/



