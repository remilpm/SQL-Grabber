 
 /* CR-P00343 - Citigroup Hire Date and Service Date patch for 'AUCGP','CGMAS','JPNNS','JPNAM' */
 
declare
min_effdt	date;

begin
     for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,a.business_unit
               from sysadm.ps_job a
               where a.business_unit in ('AUCGP','CGMAS','JPNNS','JPNAM')
               and effdt =    (select max(effdt) from sysadm.ps_job
               			where emplid = a.emplid 
               			and empl_rcd = a.empl_rcd and effdt <= sysdate)
               and effseq =   (select max(effseq) from sysadm.ps_job
                                where emplid = a.emplid and effdt = a.effdt
                                and empl_rcd = a.empl_rcd)
               and exists (select 1 from sysadm.ps_employment
               		   where emplid = a.emplid and empl_rcd = a.empl_rcd
               		   and (cgap_citihire_dt is null or service_dt is null)))
loop

   select min(effdt) into min_effdt from ps_job
   where emplid = i.emplid
   and action in ('HIR','REH');
   
   update sysadm.ps_employment set cgap_citihire_dt=min_effdt
   where emplid = i.emplid   
   and cgap_citihire_dt is null;   
   	
   update sysadm.ps_employment set service_dt=min_effdt
   where emplid = i.emplid
   and service_dt is null;
     
end loop;
commit;
end;
/
