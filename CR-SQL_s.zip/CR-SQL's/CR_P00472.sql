/* CR-P00472 - Personal Status Patch for 'INDCB' */


begin
     for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,a.business_unit,a.company
               from sysadm.ps_job a
               where a.business_unit = 'INDCB' 
               and a.company = 'INB'
               and effdt =    (select max(effdt) from sysadm.ps_job
               			where emplid = a.emplid 
               			and empl_rcd = a.empl_rcd and effdt <= sysdate)
               and effseq =   (select max(effseq) from sysadm.ps_job
                                where emplid = a.emplid and effdt = a.effdt
                                and empl_rcd = a.empl_rcd))               
loop

      
   update sysadm.ps_person set per_status = 'N'
   where emplid = i.emplid;	
   
end loop;
commit;
end;
/