/* CR-P00486 - Temp to Part Time patch for Active Employees(TOS) Regional */



begin
     for i in (select *   from sysadm.ps_job a
               where a.empl_status in ('A','L','P','S','W','E','Y') 
               and full_part_time='T'
               and effdt =   (select max(effdt) from sysadm.ps_job
		                    where emplid = a.emplid
		                    and empl_rcd = a.empl_rcd
		                    and effdt <= sysdate)
	       and effseq =   (select max(effseq) from sysadm.ps_job 
		                      where emplid = a.emplid
		                      and empl_rcd = a.empl_rcd
		                      and effdt = a.effdt))            
               
loop   
   
   update sysadm.ps_job set full_part_time ='P'
   where emplid = i.emplid   
     and effdt =  i.effdt
     and effseq = i.effseq
     and empl_rcd=i.empl_rcd;  
     
     INSERT INTO PS_CGAP_AUDIT_JOB 
     	SELECT 
     	'WC70754',
     	 SYSDATE,
     	 'C',
     	i.EMPLID,
     	i.EMPL_RCD,
     	i.EFFDT,
     	i.EFFSEQ,
     	i.POSITION_NBR,
     	i.POSITION_OVERRIDE,
     	i.POSN_CHANGE_RECORD,
     	i.EMPL_STATUS,
     	i.ACTION,
     	i.ACTION_DT,
     	i.ACTION_REASON,
     	i.EMPL_CLASS,
     	i.JOBCODE,
     	i.GRADE,
     	i.DEPTID,
     	i.LOCATION,
     	i.TAX_LOCATION_CD,
     	i.JOB_ENTRY_DT,
     	i.DEPT_ENTRY_DT,
     	i.POSITION_ENTRY_DT,
     	i.BAS_GROUP_ID,
     	i.ELIG_CONFIG1,
     	i.ELIG_CONFIG2,
     	i.ELIG_CONFIG3,
     	i.ELIG_CONFIG4,
     	i.ELIG_CONFIG5,
     	i.ELIG_CONFIG6,
     	i.ELIG_CONFIG7,
     	i.ELIG_CONFIG8,
     	i.ELIG_CONFIG9,
     	i.BEN_STATUS,
     	i.BAS_ACTION,
     	i.COBRA_ACTION,
     	i.EMPL_TYPE,
     	i.HOLIDAY_SCHEDULE,
     	i.STD_HRS_FREQUENCY,
     	i.OFFICER_CD,
     	i.GRADE_ENTRY_DT,
     	i.STEP,
     	i.STEP_ENTRY_DT,
     	i.GL_PAY_TYPE,
     	i.ACCT_CD,
     	i.EARNS_DIST_TYPE,
     	i.SALARY_MATRIX_CD,
     	i.ANNUAL_RT,
     	i.MONTHLY_RT,
     	i.DAILY_RT,
     	i.HOURLY_RT,
     	i.ANNL_BENEF_BASE_RT,
     	i.SHIFT_RT,
     	i.SHIFT_FACTOR,
     	i.SETID_DEPT,
     	i.SETID_JOBCODE,
     	i.SETID_LOCATION,
     	i.SETID_SALARY,
     	i.REG_REGION,
     	i.DIRECTLY_TIPPED,
     	i.FLSA_STATUS,
     	i.EEO_CLASS,
     	i.FUNCTION_CD,
     	i.TARIFF_GER,
     	i.TARIFF_AREA_GER,
     	i.PERFORM_GROUP_GER,
     	i.HOURLY_RT_FRA,
     	i.ACCDNT_CD_FRA,
     	i.VALUE_1_FRA,
     	i.VALUE_2_FRA,
     	i.VALUE_3_FRA,
     	i.VALUE_4_FRA,
     	i.VALUE_5_FRA,
     	i.SHIFT,
     	i.REG_TEMP,
     	i.FULL_PART_TIME,                                   
     	i.SAL_ADMIN_PLAN,
     	i.COMPRATE,
     	i.COMP_FREQUENCY,
     	i.CURRENCY_CD,
     	i.STD_HOURS,
     	i.REVIEW_DT,
     	i.RATING_SCALE,
     	i.REVIEW_RATING,
     	i.CHANGE_AMT,
     	i.CHANGE_PCT,
     	i.COMPANY,
     	i.PAYGROUP,
     	i.CGAP_MG_ORG,
     	i.BUSINESS_UNIT,
     	i.CTG_RATE,
     	i.PAID_HOURS,
     	i.PAID_FTE,
     	i.PAID_HRS_FREQUENCY,
     	i.ANNL_BEN_BASE_OVRD,
     	i.BENEFIT_PROGRAM,
     	i.UPDATE_PAYROLL,
     	i.MATRICULA_NBR,
     	i.SOC_SEC_RISK_CODE,
     	i.EXEMPT_JOB_LBR,
     	i.EXEMPT_HOURS_MONTH,
     	i.CURRENCY_CD1,
     	i.ENTRY_DATE,
     	i.LABOR_AGREEMENT,
     	i.EMPL_CTG,
     	i.EMPL_CTG_L1,
     	i.EMPL_CTG_L2,
     	i.SETID_LBR_AGRMNT,
     	i.GP_PAYGROUP,
     	i.GP_DFLT_ELIG_GRP,
     	i.GP_DFLT_CURRTTYP,
     	i.GP_ELIG_GRP,
     	i.CUR_RT_TYPE,
     	i.GP_DFLT_EXRTDT,
     	i.GP_ASOF_DT_EXG_RT,
     	i.ADDS_TO_FTE_ACTUAL,
     	i.CLASS_INDC,
     	i.ENCUMB_OVERRIDE,
     	i.FICA_STATUS_EE,
     	i.FTE,
     	i.PRORATE_CNT_AMT,
     	i.PAY_SYSTEM_FLG,
     	i.BORDER_WALKER,
     	i.LUMP_SUM_PAY,
     	i.CONTRACT_NUM,
     	i.BENEFIT_SYSTEM,
     	i.WORK_DAY_HOURS,
     	i.SUPERVISOR_ID,
     	i.REPORTS_TO,
     	i.FORCE_PUBLISH,
     	i.JOB_DATA_SRC_CD,
     	i.ESTABID,
     	i.GDW_DEPTID FROM PS_JOB  WHERE
     	emplid   = i.emplid and
     	effdt    = i.effdt  and
     	effseq   = i.effseq and
empl_rcd = i.empl_rcd;   
     
end loop;
commit;
end;
/
