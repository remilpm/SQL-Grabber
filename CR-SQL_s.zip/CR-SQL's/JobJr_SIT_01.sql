 delete  from sysadm.ps_job_jr a
 where a.emplid = '1000179756'   
 and a.effdt = '23-SEP-04';
 commit;
 
 
 
 
 
      