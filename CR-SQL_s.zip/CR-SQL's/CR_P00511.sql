declare
ins_effdt	date;
ins_flag	varchar2(1) := 0;
row_cnt		number(2);
data_cnt	number(2);
j		number;
no_ins		number;
max_rvw_Effdt	date;

begin
for i in (select * from ps_job a
	  where a.rating_scale <> ' ' or a.review_rating <> ' ' or a.review_dt is not null
	  and exists (select 1 from ps_job b 
	  		where emplid = a.emplid
	  		and effdt = (select max(effdt) from ps_job where emplid = b.emplid and empl_rcd = b.empl_rcd and effdt <= sysdate)
	  		and effseq = (select max(effseq) from ps_job where emplid = b.emplid and empl_rcd = b.empl_rcd and effdt = b.effdt)
	  		and business_unit = 'AUCGP')
	  )
loop
/*dbms_output.put_line('JOB'||';'||i.emplid||';'||i.empl_rcd||';'||i.rating_scale||';'||i.review_rating||';'||i.review_dt);*/

   	/* Audit JOB */
	insert into ps_cgap_audit_job
	select  
	'AM01466',
	sysdate,
	'C',
	EMPLID,
	EMPL_RCD,
	effdt,
	effseq,
	POSITION_NBR,
	POSITION_OVERRIDE,
	POSN_CHANGE_RECORD,
	EMPL_STATUS,
	action,
	sysdate,
	action_reason,
	EMPL_CLASS,
	jobcode,
	GRADE,
	DEPTID,
	LOCATION,
	TAX_LOCATION_CD,
	JOB_ENTRY_DT,
	DEPT_ENTRY_DT,
	POSITION_ENTRY_DT,
	BAS_GROUP_ID,
	ELIG_CONFIG1,
	ELIG_CONFIG2,
	ELIG_CONFIG3,
	ELIG_CONFIG4,
	ELIG_CONFIG5,
	ELIG_CONFIG6,
	ELIG_CONFIG7,
	ELIG_CONFIG8,
	ELIG_CONFIG9,
	BEN_STATUS,
	BAS_ACTION,
	COBRA_ACTION,
	EMPL_TYPE,
	HOLIDAY_SCHEDULE,
	STD_HRS_FREQUENCY,
	OFFICER_CD,
	GRADE_ENTRY_DT,
	STEP,
	STEP_ENTRY_DT,
	GL_PAY_TYPE,
	ACCT_CD,
	EARNS_DIST_TYPE,
	SALARY_MATRIX_CD,
	ANNUAL_RT,
	MONTHLY_RT,
	DAILY_RT,
	HOURLY_RT,
	ANNL_BENEF_BASE_RT,
	SHIFT_RT,
	SHIFT_FACTOR,
	SETID_DEPT,
	SETID_JOBCODE,
	SETID_LOCATION,
	SETID_SALARY,
	REG_REGION,
	DIRECTLY_TIPPED,
	FLSA_STATUS,
	EEO_CLASS,
	FUNCTION_CD,
	TARIFF_GER,
	TARIFF_AREA_GER,
	PERFORM_GROUP_GER,
	HOURLY_RT_FRA,
	ACCDNT_CD_FRA,
	VALUE_1_FRA,
	VALUE_2_FRA,
	VALUE_3_FRA,
	VALUE_4_FRA,
	VALUE_5_FRA,
	SHIFT,
	REG_TEMP,
	FULL_PART_TIME,
	SAL_ADMIN_PLAN,
	COMPRATE,
	COMP_FREQUENCY,
	CURRENCY_CD,
	STD_HOURS,
	REVIEW_DT,
	RATING_SCALE,
	REVIEW_RATING,
	CHANGE_AMT,
	CHANGE_PCT,
	COMPANY,
	PAYGROUP,
	CGAP_MG_ORG,
	BUSINESS_UNIT,
	CTG_RATE,
	PAID_HOURS,
	PAID_FTE,
	PAID_HRS_FREQUENCY,
	ANNL_BEN_BASE_OVRD,
	BENEFIT_PROGRAM,
	UPDATE_PAYROLL,
	MATRICULA_NBR,
	SOC_SEC_RISK_CODE,
	EXEMPT_JOB_LBR,
	EXEMPT_HOURS_MONTH,
	CURRENCY_CD1,
	ENTRY_DATE,
	LABOR_AGREEMENT,
	EMPL_CTG,
	EMPL_CTG_L1,
	EMPL_CTG_L2,
	SETID_LBR_AGRMNT,
	GP_PAYGROUP,
	GP_DFLT_ELIG_GRP,
	GP_DFLT_CURRTTYP,
	GP_ELIG_GRP,
	CUR_RT_TYPE,
	GP_DFLT_EXRTDT,
	GP_ASOF_DT_EXG_RT,
	ADDS_TO_FTE_ACTUAL,
	CLASS_INDC,
	ENCUMB_OVERRIDE,
	FICA_STATUS_EE,
	FTE,
	PRORATE_CNT_AMT,
	PAY_SYSTEM_FLG,
	BORDER_WALKER,
	LUMP_SUM_PAY,
	CONTRACT_NUM,
	BENEFIT_SYSTEM,
	WORK_DAY_HOURS,
	SUPERVISOR_ID,
	REPORTS_TO,
	FORCE_PUBLISH,
	JOB_DATA_SRC_CD,
	ESTABID,
	GDW_DEPTID
	from ps_job 
	where emplid = i.emplid and effdt = i.effdt 
	and effseq = i.effseq and empl_rcd = i.empl_rcd;

	update ps_job a set a.rating_scale = ' ' , a.review_rating = ' ' , a.review_dt = ''
	where emplid = i.emplid and effdt = i.effdt 
	and effseq = i.effseq and empl_rcd = i.empl_rcd;

end loop;
commit;
end;
/

