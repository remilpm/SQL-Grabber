declare
pay_plan_yr		number(4);
begin
/* VC Plan year patch for Hong Kong - CR #321 */
for i in (select * from ps_cgap_oth_bonus b where (cgap_plan_year = 0 or cgap_plan_year is null)
	     	  and exists (select 1 from ps_job a
	  		where emplid = b.emplid
	  		and effdt = (select max(effdt) from ps_job where emplid = a.emplid and effdt <= sysdate)
	  		and effseq = (select max(effseq) from ps_job where emplid = a.emplid and effdt = a.effdt)
	  		and empl_rcd = (select max(empl_rcd) from ps_job where emplid = a.emplid and effdt = a.effdt and effseq = a.effseq)
	  		and business_unit = 'CGMAS'))
loop
pay_plan_yr := to_char(i.effdt,'YYYY');

update ps_cgap_oth_bonus set cgap_plan_year = pay_plan_yr
where emplid = i.emplid and effdt = i.effdt and cgap_comp_cd = i.cgap_comp_cd
and (cgap_plan_year = 0 or cgap_plan_year is null);

insert into ps_cgap_audit_bonu
select 
'AC40090',            
sysdate,            
'C'             ,
'CGAP_OTH_BONUS',          
i.EMPLID                 ,
i.EFFDT                  ,
i.CGAP_COMP_CD           ,
i.BUSINESS_UNIT          ,
i.CGAP_BONUS_AMT         ,
i.CGAP_VC_AMOUNT         ,
i.CGAP_SRP_AMT           ,
pay_plan_yr         ,
i.CURRENCY_CD            ,
i.CGAP_CAP_ELIGIB        ,
i.CGAP_COMP_PAID_DT,
i.CGAP_REMARKS           
from ps_cgap_oth_bonus
where emplid = i.emplid and effdt = i.effdt and cgap_comp_cd = i.cgap_comp_cd;

end loop;
commit;
end;
/
