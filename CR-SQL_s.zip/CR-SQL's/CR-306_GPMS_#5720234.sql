/* CR-P00306 - GPMS #5720234:  Employee Class Patch for JPNCB- All rows */
begin
for i in (select a.emplid,a.effdt,a.effseq,a.empl_rcd,a.paygroup,  a.empl_class,a.business_unit
                                     from sysadm.ps_job a
        where effdt =  (select max(effdt) from sysadm.ps_job
                                                   where emplid = a.emplid
                                                   and effdt <= sysdate)
        and effseq =   (select max(effseq) from sysadm.ps_job 
                                                   where emplid = a.emplid 
                                                   and effdt = a.effdt)
       and empl_rcd = (select max(empl_rcd) from sysadm.ps_job
                                                    where emplid = a.emplid 
                                                    and effdt = a.effdt and effseq = a.effseq)
                  and business_unit = 'JPNCB' )
loop
/* (1) If Empl_Class = 'SEA', Set paygroup = 'SEA' and empl_class = 'D' */

update sysadm.ps_job set empl_class = 'D', paygroup='SEA' where empl_class='SEA' and emplid =   i.emplid;

/* (2) If Empl_Class = 'SE', Set paygroup = 'SE' and empl_class = 'D' */
update sysadm.ps_job set empl_class = 'D', paygroup='SE' where empl_class='SE' and emplid =   i.emplid;

/* (3) If Empl_Class = 'AA',  Set paygroup = 'AA' and empl_class = 'D' */
update sysadm.ps_job set empl_class = 'D', paygroup='AA' where empl_class= 'AA' and emplid =   i.emplid;

/* (4) If Empl_Class = 'PT',  Set paygroup = 'PT' and empl_class = 'D' */
update sysadm.ps_job set empl_class = 'D', paygroup='PT' where empl_class='PT' and emplid =   i.emplid;

/* (5) If Empl_Class = 'R' and paygroup='OTA',   Set paygroup = 'CS' and empl_class = 'D' */
update sysadm.ps_job set empl_class = 'D', paygroup='CS' where empl_class= 'R' and paygroup='OTA'
and emplid =   i.emplid;

/* (6) If Empl_Class = 'R' and paygroup='NOT',   Set paygroup = 'CSN' and empl_class = 'D' */
update sysadm.ps_job set empl_class = 'D', paygroup='CSN' where empl_class= 'R' and paygroup='NOT'  
and emplid =  i.emplid;
end loop;
commit;
end;
/


