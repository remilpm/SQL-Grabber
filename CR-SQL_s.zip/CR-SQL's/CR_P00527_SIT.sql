/*CR-527 Error Data Simulation */




begin
for i in (select * from sysadm.ps_job_jr a
where a.emplid in ('1000000506','1000002568')
and a.effdt =  (select max(effdt) from sysadm.ps_job_jr
		where emplid = a.emplid and effdt <= sysdate)
		and effseq =   (select max(effseq) from sysadm.ps_job_jr 
		                where emplid = a.emplid and effdt = a.effdt)
		and empl_rcd = (select max(empl_rcd) from sysadm.ps_job_jr
		                where emplid = a.emplid 
		                and effdt = a.effdt and effseq = a.effseq))
		
loop


If i.emplid ='1000000506' Then


begin

INSERT INTO PS_JOB_JR
SELECT 
'0003319904',                         
0,                       
'21-FEB-2000',                          
2,                        
SYSDATE,                   
i. LASTUPDOPRID,                   
i. TAXCODE_UK,                     
i. TAX_BASIS_UK,                   
i. WORKER_TYPE_MEX,                
i. REDUCED_WEEK_MEX,               
i. LOCATED_CD_MEX,               
i. SALARY_TYPE_MEX,               
i. IMS_TERM_DT_MEX,               
i. CASUAL_IND,               
i. SALARY_PACKAGED,               
i. PAYROLL_STATE_AUS,
i. CLASSN_CURRENT_AUS,             
i. WORK_SECTOR_AUS,                
i. FUNCTION_AUS,                   
i. ANN_CNTACT_HRS_AUS,             
i. TEACH_WEEKS_AUS,                
i. CASUAL_TYPE_AUS,                
i. TERM_TYPE_AUS,                  
i. TERM_LTD_AUS,                   
i. BALANCE_GRP_NUM,                
i. FP_ACTION_2,                    
i. CTG_RATE,                       
i. FP_LEGALSTAT_CD,                
i. FP_SCNDMT_CD,                   
i. FP_SCND_TYP,                    
i. FP_CIVIL_PENSION,               
i. FP_SOURCE_ORG,                  
i. FP_RECEP_ORG,                   
i. FP_RETURN_CD,                   
i. FP_PR_LEGSTA,                   
i. FP_FOREND_DT,                   
i. FP_END_DT,                      
i. FP_CAREFRZPCT,                  
i. FP_HIR_DOS_SIT,                 
i. FP_PT_PCT_DET,                  
i. FP_TITLE_NUM,                   
i. FP_DURATION_PCT,                
i. FP_RATING_PRS_FLG,              
i. FP_BUDGET_NBR,                  
i. FP_HDCNT_NBR,                   
i. FP_POTENT_NBR,                  
i. FP_RANK_CD,                     
i. FP_STEP_CD,                     
i. FP_RK_ENT_DT,                   
i. FP_CORPS_CD,                    
i. FP_CHG_COR_DT,                  
i. FP_CATG_FP,                     
i. FP_CATG_LEVEL,                  
i. FP_RK_TRIALPD,                  
i. FP_STEP_END_DT,                 
i. FP_FOR_PROM_DT,                 
i. FP_NOMINATION_DT,               
i. FP_TRAINEE,                     
i. FP_TRNE_POSN,                   
i. FP_RK_PD_END_DT,                
i. FP_SANCTION,                    
i. FP_DOWN_GRA,                    
i. FP_APPL_SAL_DT,                 
i. FP_CHG_IND,                     
i. FP_CLD_INST,                    
i. FP_SETID_RANK,                  
i. FP_INSTALL_DT,                  
i. FP_EQUIV_STEP,                  
i. FP_STEP_CD2,                    
i. FP_BUSINESS_CD,                 
i. FP_APPL_DT,                     
i. FP_CHG_SAL,                     
i. FP_POINTYP_CD,                  
i. FP_GROSS_IND,                   
i. FP_INCS_IND,                    
i. FP_INCS_IND2,                  
i. FP_PT_PCT,                      
i. FP_PT_END_DT,                   
i. FP_PT_FOREND_DT,                
i. FP_COMPRATE,                   
i. FP_INST_STAT,                   
i. FP_RETROSPECT,                  
i. FP_ROW_END_DT,                  
i. LAST_UPDATE_DATE,               
i. OTHER_ID_JPN,                   
i. INTCP_XFR_FLG,                 
i. INTCP_XFR_START_DT,             
i. INTCP_XFR_END_DT,               
i. INTCP_BUS_UNIT,                 
i. INTCP_DEPTID,                   
i. INTCP_DEPTID2,                  
i. INTCP_SETID_DEPT,              
i. INTCP_COMPANY,                  
i. INTCP_COMPANY2,                 
i. INTCP_SUPV_LVL_ID,              
i. INTCP_SUPV_LVL_ID2,             
i. SUPV_LVL_ID,                   
i. EXPECTED_END_DATE,             
i. AUTO_END_FLG,                   
i. DUTIES_TYPE,                    
i. ASSIGNMENT_ID,                  
i. TARGET_COMPRATE,                
i. CMP_DONT_ABSORB,                
i. SSN_EMPLOYER,                   
i. UNITA_PROD_CD,                  
i. ACTION_ITA,                    
i. ACTION_REASON_ITA,              
i. SPECIAL_HIRCTG_ITA,             
i. PART_TIME_TYPE_ITA,             
i. PART_TIME_PERC_ITA,             
i. PARTTIME_ENDDT_ITA,             
i. CGAP_REMN_TYPE   FROM PS_JOB_JR WHERE
	emplid   = i.emplid and
	effdt    = i.effdt  and
	effseq   = i.effseq and
empl_rcd = i.empl_rcd;

end;
End If;



If i.emplid ='1000002568' Then

begin

INSERT INTO PS_JOB_JR
SELECT 
'0003319904',                         
0,                       
'01-JUL-2001',                          
2,                        
SYSDATE,                   
i. LASTUPDOPRID,                   
i. TAXCODE_UK,                     
i. TAX_BASIS_UK,                   
i. WORKER_TYPE_MEX,                
i. REDUCED_WEEK_MEX,               
i. LOCATED_CD_MEX,               
i. SALARY_TYPE_MEX,               
i. IMS_TERM_DT_MEX,               
i. CASUAL_IND,               
i. SALARY_PACKAGED,               
i. PAYROLL_STATE_AUS,
i. CLASSN_CURRENT_AUS,             
i. WORK_SECTOR_AUS,                
i. FUNCTION_AUS,                   
i. ANN_CNTACT_HRS_AUS,             
i. TEACH_WEEKS_AUS,                
i. CASUAL_TYPE_AUS,                
i. TERM_TYPE_AUS,                  
i. TERM_LTD_AUS,                   
i. BALANCE_GRP_NUM,                
i. FP_ACTION_2,                    
i. CTG_RATE,                       
i. FP_LEGALSTAT_CD,                
i. FP_SCNDMT_CD,                   
i. FP_SCND_TYP,                    
i. FP_CIVIL_PENSION,               
i. FP_SOURCE_ORG,                  
i. FP_RECEP_ORG,                   
i. FP_RETURN_CD,                   
i. FP_PR_LEGSTA,                   
i. FP_FOREND_DT,                   
i. FP_END_DT,                      
i. FP_CAREFRZPCT,                  
i. FP_HIR_DOS_SIT,                 
i. FP_PT_PCT_DET,                  
i. FP_TITLE_NUM,                   
i. FP_DURATION_PCT,                
i. FP_RATING_PRS_FLG,              
i. FP_BUDGET_NBR,                  
i. FP_HDCNT_NBR,                   
i. FP_POTENT_NBR,                  
i. FP_RANK_CD,                     
i. FP_STEP_CD,                     
i. FP_RK_ENT_DT,                   
i. FP_CORPS_CD,                    
i. FP_CHG_COR_DT,                  
i. FP_CATG_FP,                     
i. FP_CATG_LEVEL,                  
i. FP_RK_TRIALPD,                  
i. FP_STEP_END_DT,                 
i. FP_FOR_PROM_DT,                 
i. FP_NOMINATION_DT,               
i. FP_TRAINEE,                     
i. FP_TRNE_POSN,                   
i. FP_RK_PD_END_DT,                
i. FP_SANCTION,                    
i. FP_DOWN_GRA,                    
i. FP_APPL_SAL_DT,                 
i. FP_CHG_IND,                     
i. FP_CLD_INST,                    
i. FP_SETID_RANK,                  
i. FP_INSTALL_DT,                  
i. FP_EQUIV_STEP,                  
i. FP_STEP_CD2,                    
i. FP_BUSINESS_CD,                 
i. FP_APPL_DT,                     
i. FP_CHG_SAL,                     
i. FP_POINTYP_CD,                  
i. FP_GROSS_IND,                   
i. FP_INCS_IND,                    
i. FP_INCS_IND2,                  
i. FP_PT_PCT,                      
i. FP_PT_END_DT,                   
i. FP_PT_FOREND_DT,                
i. FP_COMPRATE,                   
i. FP_INST_STAT,                   
i. FP_RETROSPECT,                  
i. FP_ROW_END_DT,                  
i. LAST_UPDATE_DATE,               
i. OTHER_ID_JPN,                   
i. INTCP_XFR_FLG,                 
i. INTCP_XFR_START_DT,             
i. INTCP_XFR_END_DT,               
i. INTCP_BUS_UNIT,                 
i. INTCP_DEPTID,                   
i. INTCP_DEPTID2,                  
i. INTCP_SETID_DEPT,              
i. INTCP_COMPANY,                  
i. INTCP_COMPANY2,                 
i. INTCP_SUPV_LVL_ID,              
i. INTCP_SUPV_LVL_ID2,             
i. SUPV_LVL_ID,                   
i. EXPECTED_END_DATE,             
i. AUTO_END_FLG,                   
i. DUTIES_TYPE,                    
i. ASSIGNMENT_ID,                  
i. TARGET_COMPRATE,                
i. CMP_DONT_ABSORB,                
i. SSN_EMPLOYER,                   
i. UNITA_PROD_CD,                  
i. ACTION_ITA,                    
i. ACTION_REASON_ITA,              
i. SPECIAL_HIRCTG_ITA,             
i. PART_TIME_TYPE_ITA,             
i. PART_TIME_PERC_ITA,             
i. PARTTIME_ENDDT_ITA,             
i. CGAP_REMN_TYPE   FROM PS_JOB_JR WHERE
	emplid   = i.emplid and
	effdt    = i.effdt  and
	effseq   = i.effseq and
empl_rcd = i.empl_rcd;
 end;
End If;

end loop;
commit;
end;
/