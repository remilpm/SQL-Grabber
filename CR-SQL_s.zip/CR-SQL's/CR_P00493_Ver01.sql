/* Below SQL is for Populating Biz Line Setup Table. One Time Load */


delete PS_CGAP_DEPT_BUSLN;
commit;
delete PS_CGAP_DEPT_RESID;
commit;

INSERT INTO PS_CGAP_DEPT_BUSLN
SELECT 
SETID,
EFFDT,
EFF_STATUS,
DEPTID,
' ',
'APAC'
FROM PS_DEPT_TBL;
COMMIT;



INSERT INTO PS_CGAP_DEPT_RESID
SELECT 
SETID,
EFFDT,
EFF_STATUS,
DEPTID,
' ',
'APAC'
FROM PS_DEPT_TBL;
COMMIT;




